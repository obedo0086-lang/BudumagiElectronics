package com.budumagi.electronics

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val REQ_EXPORT = 701
private const val REQ_IMPORT = 702

class StoreDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "budumagi.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, barcode TEXT DEFAULT '', qty INTEGER NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, cost REAL NOT NULL DEFAULT 0, low_stock INTEGER NOT NULL DEFAULT 5)""")
        db.execSQL("""CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, product_name TEXT, qty INTEGER, total REAL, profit REAL, created_at TEXT)""")
        db.execSQL("""CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, details TEXT, amount REAL, paid REAL DEFAULT 0, created_at TEXT)""")
        db.execSQL("""CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT, amount REAL, created_at TEXT)""")
        db.execSQL("""CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, qty INTEGER, total REAL, created_at TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun rows(sql: String, args: Array<String> = emptyArray(), block: (android.database.Cursor) -> Unit) {
        readableDatabase.rawQuery(sql, args).use { c -> while (c.moveToNext()) block(c) }
    }
    fun addProduct(name: String, barcode: String, qty: Int, price: Double, cost: Double, low: Int) {
        val v = ContentValues().apply {
            put("name", name); put("barcode", barcode); put("qty", qty)
            put("price", price); put("cost", cost); put("low_stock", low)
        }
        writableDatabase.insert("products", null, v)
    }
    fun updateQty(id: Int, qty: Int) {
        writableDatabase.execSQL("UPDATE products SET qty=? WHERE id=?", arrayOf(qty, id))
    }
    fun product(id: Int): Array<String>? {
        var out: Array<String>? = null
        rows("SELECT name,qty,price,cost FROM products WHERE id=?", arrayOf(id.toString())) {
            out = arrayOf(it.getString(0), it.getInt(1).toString(), it.getDouble(2).toString(), it.getDouble(3).toString())
        }
        return out
    }
    fun addSale(id: Int, name: String, qty: Int, total: Double, profit: Double) {
        val v = ContentValues().apply {
            put("product_id", id); put("product_name", name); put("qty", qty)
            put("total", total); put("profit", profit); put("created_at", stamp())
        }
        writableDatabase.insert("sales", null, v)
    }
    fun addDebt(customer: String, details: String, amount: Double) {
        val v = ContentValues().apply { put("customer", customer); put("details", details); put("amount", amount); put("paid", 0); put("created_at", stamp()) }
        writableDatabase.insert("debts", null, v)
    }
    fun payDebt(id: Int, amount: Double) { writableDatabase.execSQL("UPDATE debts SET paid=MIN(amount,paid+?) WHERE id=?", arrayOf(amount, id)) }
    fun addExpense(desc: String, amount: Double) {
        val v = ContentValues().apply { put("description", desc); put("amount", amount); put("created_at", stamp()) }
        writableDatabase.insert("expenses", null, v)
    }
    fun addPurchase(id: Int, qty: Int, total: Double) {
        val v = ContentValues().apply { put("product_id", id); put("qty", qty); put("total", total); put("created_at", stamp()) }
        writableDatabase.insert("purchases", null, v)
    }
    fun stamp() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
    fun totals(): DoubleArray {
        var sales=0.0; var profit=0.0; var debts=0.0; var expenses=0.0; var count=0.0; var low=0.0
        rows("SELECT COALESCE(SUM(total),0),COALESCE(SUM(profit),0) FROM sales") { sales=it.getDouble(0); profit=it.getDouble(1) }
        rows("SELECT COALESCE(SUM(amount-paid),0) FROM debts") { debts=it.getDouble(0) }
        rows("SELECT COALESCE(SUM(amount),0) FROM expenses") { expenses=it.getDouble(0) }
        rows("SELECT COUNT(*) FROM products") { count=it.getDouble(0) }
        rows("SELECT COUNT(*) FROM products WHERE qty<=low_stock") { low=it.getDouble(0) }
        return doubleArrayOf(sales, profit, debts, expenses, count, low)
    }
    fun exportJson(): String {
        val root = JSONObject()
        val tables = listOf("products","sales","debts","expenses","purchases")
        for (table in tables) {
            val arr = JSONArray()
            rows("SELECT * FROM $table") { c ->
                val obj = JSONObject()
                for (i in 0 until c.columnCount) {
                    val key = c.getColumnName(i)
                    when (c.getType(i)) {
                        android.database.Cursor.FIELD_TYPE_INTEGER -> obj.put(key, c.getLong(i))
                        android.database.Cursor.FIELD_TYPE_FLOAT -> obj.put(key, c.getDouble(i))
                        android.database.Cursor.FIELD_TYPE_NULL -> obj.put(key, JSONObject.NULL)
                        else -> obj.put(key, c.getString(i))
                    }
                }
                arr.put(obj)
            }
            root.put(table, arr)
        }
        return root.toString(2)
    }
    fun importJson(json: String) {
        val root = JSONObject(json)
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (t in listOf("products","sales","debts","expenses","purchases")) {
                db.delete(t, null, null)
                val arr = root.optJSONArray(t) ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i); val v = ContentValues()
                    val keys = o.keys()
                    while (keys.hasNext()) {
                        val k = keys.next(); val x = o.get(k)
                        when (x) {
                            JSONObject.NULL -> v.putNull(k)
                            is Int -> v.put(k, x)
                            is Long -> v.put(k, x)
                            is Double -> v.put(k, x)
                            is Boolean -> v.put(k, if (x) 1 else 0)
                            else -> v.put(k, x.toString())
                        }
                    }
                    db.insert(t, null, v)
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}

class MainActivity : Activity() {
    private lateinit var db: StoreDb
    private lateinit var body: LinearLayout
    private var role = "owner"
    private val prefs by lazy { getSharedPreferences("budumagi_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = StoreDb(this)
        if (!prefs.contains("pin_hash")) setupPin() else login()
    }

    private fun setupPin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,16,32,8) }
        box.addView(label("Tengeneza PIN mbili tofauti kwa usalama. PIN iwe tarakimu 4–12."))
        val ownerPin = EditText(this).apply { hint="PIN ya mmiliki"; inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        val staffPin = EditText(this).apply { hint="PIN ya mfanyakazi"; inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        box.addView(ownerPin); box.addView(staffPin)
        AlertDialog.Builder(this).setTitle("BUDUMAGI ELECTRONICS")
            .setView(box).setCancelable(false)
            .setPositiveButton("Hifadhi") { _, _ ->
                val o=ownerPin.text.toString(); val st=staffPin.text.toString()
                if (o.length !in 4..12 || st.length !in 4..12 || o==st) {
                    toast("PIN zote ziwe tarakimu 4–12 na zitofautiane"); setupPin()
                } else {
                    prefs.edit().putString("owner_pin_hash", hash(o)).putString("staff_pin_hash", hash(st)).apply()
                    login()
                }
            }.show()
    }
    private fun hash(s: String) = java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun login() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,16,32,8) }
        val p=EditText(this).apply { hint="PIN"; inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        val r=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Mmiliki","Mfanyakazi")) }
        box.addView(r); box.addView(p)
        AlertDialog.Builder(this).setTitle("Ingia BUDUMAGI").setView(box).setCancelable(false)
            .setPositiveButton("Ingia") { _, _ ->
                val chosenRole=if(r.selectedItemPosition==0) "owner" else "staff"
                val expected=if(chosenRole=="owner") prefs.getString("owner_pin_hash","") else prefs.getString("staff_pin_hash","")
                if (hash(p.text.toString()) != expected) { toast("PIN si sahihi"); login() }
                else { role=chosenRole; home() }
            }.show()
    }
    private fun home() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(0xFFF4F6F8.toInt()) }
        val header = TextView(this).apply {
            text="BUDUMAGI ELECTRONICS"; textSize=22f; setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, Typeface.BOLD); setPadding(18,22,18,22); setBackgroundColor(0xFF123B5D.toInt())
        }
        root.addView(header)
        val scroll=ScrollView(this)
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,12,14,24) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(6,6,6,6); setBackgroundColor(0xFFFFFFFF.toInt()) }
        val items = mutableListOf("Muhtasari","Bidhaa","Mauzo","Madeni","Matumizi")
        if(role=="owner") items.addAll(listOf("Ripoti","Backup"))
        items.forEach { name ->
            val b=Button(this).apply { text=name; textSize=10f; setPadding(2,4,2,4); setOnClickListener { showPage(name) } }
            nav.addView(b, LinearLayout.LayoutParams(0,52,1f))
        }
        root.addView(nav)
        setContentView(root); showPage("Muhtasari")
    }
    private fun showPage(page: String) {
        body.removeAllViews()
        when(page) {
            "Muhtasari" -> dashboard()
            "Bidhaa" -> products()
            "Mauzo" -> sales()
            "Madeni" -> debts()
            "Matumizi" -> expenses()
            "Ripoti" -> reports()
            "Backup" -> backup()
        }
    }
    private fun label(s:String): TextView = TextView(this).apply { text=s; textSize=16f; setTextColor(0xFF172B3A.toInt()); setPadding(4,10,4,10) }
    private fun heading(s:String) { body.addView(TextView(this).apply { text=s; textSize=20f; typeface=Typeface.DEFAULT_BOLD; setTextColor(0xFF123B5D.toInt()); setPadding(4,10,4,12) }) }
    private fun action(s:String, f:()->Unit) { body.addView(Button(this).apply { text=s; setOnClickListener { f() } }) }
    private fun toast(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun money(v:Double) = "TZS " + String.format(Locale.US,"%,.0f",v)
    private fun field(hint:String, numeric:Boolean=false) = EditText(this).apply {
        this.hint=hint; setSingleLine(true)
        if(numeric) inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    private fun form(title:String, fields:List<EditText>, submit:String, done:(List<String>)->Unit) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,8,20,0) }
        fields.forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("Ghairi",null)
            .setPositiveButton(submit) { _, _ -> done(fields.map { it.text.toString().trim() }) }.show()
    }
    private fun dashboard() {
        heading("Muhtasari wa biashara")
        val t=db.totals()
        listOf("Jumla ya mauzo: ${money(t[0])}","Faida ghafi ya mauzo: ${money(t[1])}","Madeni yanayosubiri: ${money(t[2])}","Matumizi: ${money(t[3])}","Idadi ya bidhaa: ${t[4].toInt()}","Bidhaa zilizo chini ya kiwango: ${t[5].toInt()}").forEach { body.addView(label(it)) }
        heading("Tahadhari ya stock")
        var found=false
        db.rows("SELECT name,qty,low_stock FROM products WHERE qty<=low_stock ORDER BY qty ASC") {
            found=true; body.addView(label("⚠ ${it.getString(0)} — stock ${it.getInt(1)} (kiwango ${it.getInt(2)})"))
        }
        if(!found) body.addView(label("Hakuna bidhaa zenye stock ndogo."))
    }
    private fun products() {
        heading("Bidhaa / Stock")
        action("+ Ongeza bidhaa") {
            val f=listOf(field("Jina la bidhaa"),field("Barcode (hiari)"),field("Kiasi cha mwanzo",true),field("Bei ya kuuza (TZS)",true),field("Bei ya kununua (TZS)",true),field("Tahadhari stock",true))
            form("Bidhaa mpya",f,"Hifadhi") { v ->
                try { if(v[0].isBlank()) throw Exception()
                    db.addProduct(v[0],v[1],v[2].toInt(),v[3].toDouble(),v[4].toDouble(),v[5].ifBlank{"5"}.toInt())
                    showPage("Bidhaa"); toast("Bidhaa imehifadhiwa")
                } catch(_:Exception) { toast("Taarifa za bidhaa si sahihi") }
            }
        }
        db.rows("SELECT id,name,barcode,qty,price,cost,low_stock FROM products ORDER BY name") { c ->
            val id=c.getInt(0); val name=c.getString(1)
            val row=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,8,8,8); setBackgroundColor(0xFFFFFFFF.toInt()) }
            row.addView(label("$name\nBarcode: ${c.getString(2)} | Stock: ${c.getInt(3)} | Bei: ${money(c.getDouble(4))}"))
            val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply { text="Ongeza stock"; setOnClickListener { stockDialog(id,name) } },LinearLayout.LayoutParams(0,-2,1f))
            actions.addView(Button(this).apply { text="Uza"; setOnClickListener { saleDialog(id) } },LinearLayout.LayoutParams(0,-2,1f))
            row.addView(actions); body.addView(row)
        }
    }
    private fun stockDialog(id:Int,name:String) {
        val f=listOf(field("Idadi ya kuongeza",true),field("Jumla ya gharama (TZS)",true))
        form("Ongeza stock: $name",f,"Hifadhi") { v ->
            try { val q=v[0].toInt(); val cost=v[1].toDouble(); if(q<=0||cost<0) throw Exception()
                val p=db.product(id)!!; db.updateQty(id,p[1].toInt()+q); db.addPurchase(id,q,cost); showPage("Bidhaa"); toast("Stock imeongezwa")
            } catch(_:Exception) { toast("Weka kiasi na gharama sahihi") }
        }
    }
    private fun sales() {
        heading("Mauzo")
        action("Chagua bidhaa kuuza") { chooseProduct { saleDialog(it) } }
        db.rows("SELECT product_name,qty,total,created_at FROM sales ORDER BY id DESC LIMIT 30") {
            body.addView(label("${it.getString(0)} × ${it.getInt(1)} — ${money(it.getDouble(2))}\n${it.getString(3)}"))
        }
    }
    private fun chooseProduct(onPick:(Int)->Unit) {
        val ids=ArrayList<Int>(); val names=ArrayList<String>()
        db.rows("SELECT id,name,qty FROM products ORDER BY name") { ids.add(it.getInt(0)); names.add("${it.getString(1)} (stock ${it.getInt(2)})") }
        if(ids.isEmpty()) { toast("Ongeza bidhaa kwanza"); return }
        AlertDialog.Builder(this).setTitle("Chagua bidhaa").setItems(names.toTypedArray()) { _, which -> onPick(ids[which]) }.show()
    }
    private fun saleDialog(id:Int) {
        val p=db.product(id) ?: return
        val f=listOf(field("Kiasi cha kuuza",true),field("Punguzo (TZS), weka 0 kama hakuna",true))
        form("Uza: ${p[0]} | stock ${p[1]}",f,"Thibitisha mauzo") { v ->
            try {
                val q=v[0].toInt(); val discount=v[1].ifBlank{"0"}.toDouble()
                val stock=p[1].toInt(); val price=p[2].toDouble(); val cost=p[3].toDouble()
                if(q<=0 || q>stock || discount<0 || discount>price*q) throw Exception()
                val total=price*q-discount; db.updateQty(id,stock-q); db.addSale(id,p[0],q,total,(price-cost)*q-discount)
                toast("Mauzo yamehifadhiwa: ${money(total)}"); showPage("Mauzo")
            } catch(_:Exception) { toast("Kiasi, stock au punguzo si sahihi") }
        }
    }
    private fun debts() {
        heading("Madeni ya wateja")
        action("+ Rekodi deni") {
            val f=listOf(field("Jina la mteja"),field("Maelezo"),field("Kiasi cha deni (TZS)",true))
            form("Deni jipya",f,"Hifadhi") { v -> try { if(v[0].isBlank()) throw Exception(); db.addDebt(v[0],v[1],v[2].toDouble()); showPage("Madeni") } catch(_:Exception) { toast("Taarifa si sahihi") } }
        }
        db.rows("SELECT id,customer,details,amount,paid,created_at FROM debts ORDER BY id DESC") { c ->
            val id=c.getInt(0); val due=c.getDouble(3)-c.getDouble(4)
            body.addView(label("${c.getString(1)} — ${c.getString(2)}\nDeni: ${money(c.getDouble(3))} | Amelipa: ${money(c.getDouble(4))} | Baki: ${money(due)}"))
            if(due>0) action("Rekodi malipo ya ${c.getString(1)}") {
                val f=listOf(field("Kiasi kilicholipwa",true))
                form("Malipo ya deni",f,"Hifadhi") { v -> try { val a=v[0].toDouble(); if(a<=0) throw Exception(); db.payDebt(id,a); showPage("Madeni") } catch(_:Exception) { toast("Kiasi si sahihi") } }
            }
        }
    }
    private fun expenses() {
        heading("Matumizi ya biashara")
        action("+ Ongeza matumizi") {
            val f=listOf(field("Maelezo ya matumizi"),field("Kiasi (TZS)",true))
            form("Matumizi mapya",f,"Hifadhi") { v -> try { if(v[0].isBlank()) throw Exception(); db.addExpense(v[0],v[1].toDouble()); showPage("Matumizi") } catch(_:Exception) { toast("Taarifa si sahihi") } }
        }
        db.rows("SELECT description,amount,created_at FROM expenses ORDER BY id DESC") {
            body.addView(label("${it.getString(0)} — ${money(it.getDouble(1))}\n${it.getString(2)}"))
        }
    }
    private fun reports() {
        heading("Ripoti za biashara")
        val t=db.totals()
        listOf("Mauzo: ${money(t[0])}","Faida ghafi: ${money(t[1])}","Madeni yaliyobaki: ${money(t[2])}","Matumizi: ${money(t[3])}","Faida baada ya matumizi (makadirio): ${money(t[1]-t[3])}").forEach { body.addView(label(it)) }
        action("Toa ripoti CSV (Excel)") { exportCsv() }
        action("Chapisha / Hifadhi PDF") { printReport() }
    }
    private fun backup() {
        heading("Backup na kurejesha taarifa")
        body.addView(label("Hifadhi backup ya bidhaa, mauzo, madeni, matumizi na manunuzi kwenye faili la JSON. Hifadhi faili hilo sehemu salama."))
        action("Tengeneza backup") { val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type="application/json"; putExtra(Intent.EXTRA_TITLE,"budumagi-backup.json") }; startActivityForResult(i,REQ_EXPORT) }
        action("Rejesha backup") { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="application/json"; addCategory(Intent.CATEGORY_OPENABLE) }; startActivityForResult(i,REQ_IMPORT) }
        action("Badili PIN ya mmiliki") { changePin() }
    }
    private fun changePin() {
        val f=listOf(field("PIN ya sasa",true),field("PIN mpya (tarakimu 4–12)",true))
        form("Badili PIN",f,"Badili") { v ->
            if(hash(v[0])!=prefs.getString("pin_hash","")) toast("PIN ya sasa si sahihi")
            else if(v[1].length !in 4..12) toast("PIN mpya iwe tarakimu 4 hadi 12")
            else { prefs.edit().putString("pin_hash",hash(v[1])).apply(); toast("PIN imebadilishwa") }
        }
    }
    private fun exportCsv() {
        val sb=StringBuilder("Aina,Jina,Kiasi,Thamani,Tarehe\\n")
        db.rows("SELECT product_name,qty,total,created_at FROM sales") { sb.append("Mauzo,${csv(it.getString(0))},${it.getInt(1)},${it.getDouble(2)},${csv(it.getString(3))}\\n") }
        db.rows("SELECT name,qty,price,'' FROM products") { sb.append("Stock,${csv(it.getString(0))},${it.getInt(1)},${it.getDouble(2)},\\n") }
        db.rows("SELECT description,0,amount,created_at FROM expenses") { sb.append("Matumizi,${csv(it.getString(0))},0,${it.getDouble(2)},${csv(it.getString(3))}\\n") }
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type="text/csv"; putExtra(Intent.EXTRA_TITLE,"budumagi-ripoti.csv") }
        pendingCsv=sb.toString(); startActivityForResult(i,REQ_EXPORT+10)
    }
    private var pendingCsv: String? = null
    private fun csv(s:String) = "\"" + s.replace("\"","\"\"") + "\""
    private fun printReport() {
        val t=db.totals()
        val html="""<html><meta charset="utf-8"><body><h1>BUDUMAGI ELECTRONICS</h1><h2>Ripoti ya biashara</h2><p>Mauzo: ${money(t[0])}</p><p>Faida ghafi: ${money(t[1])}</p><p>Madeni yaliyobaki: ${money(t[2])}</p><p>Matumizi: ${money(t[3])}</p><p>Faida baada ya matumizi: ${money(t[1]-t[3])}</p></body></html>"""
        val w=android.webkit.WebView(this)
        w.loadDataWithBaseURL(null,html,"text/html","UTF-8",null)
        w.webViewClient=object:android.webkit.WebViewClient() {
            override fun onPageFinished(view:android.webkit.WebView?, url:String?) {
                val pm=getSystemService(PRINT_SERVICE) as android.print.PrintManager
                pm.print("Budumagi_Ripoti",view!!.createPrintDocumentAdapter("Budumagi_Ripoti"),android.print.PrintAttributes.Builder().build())
            }
        }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data?.data==null) return
        try {
            if(requestCode==REQ_EXPORT+10) {
                contentResolver.openOutputStream(data.data!!)?.use { it.write((pendingCsv ?: "").toByteArray()) }
                toast("Ripoti ya CSV imehifadhiwa")
            } else if(requestCode==REQ_EXPORT) {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(db.exportJson().toByteArray()) }
                toast("Backup imehifadhiwa")
            } else if(requestCode==REQ_IMPORT) {
                val json=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use { it.readText() } ?: ""
                AlertDialog.Builder(this).setTitle("Thibitisha kurejesha backup")
                    .setMessage("Taarifa zilizopo zitabadilishwa na backup hii. Endelea?")
                    .setNegativeButton("Ghairi",null).setPositiveButton("Rejesha") { _, _ ->
                        try { db.importJson(json); showPage("Muhtasari"); toast("Backup imerejeshwa") }
                        catch(e:Exception) { toast("Backup haijasomeka") }
                    }.show()
            }
        } catch(e:Exception) { toast("Imeshindikana kuhifadhi/kusoma faili") }
    }
}
