# BUDUMAGI ELECTRONICS — Android Studio project

Huu ni mradi wa Android wa Kotlin (native Android), si HTML. Unaweza kufunguliwa kwenye Android Studio na kujengwa kuwa APK.

## Mahitaji
- Android Studio ya sasa
- JDK 17 (Android Studio inaweza kutumia JBR yake)
- Android SDK Platform 35 na Build Tools zinazolingana
- Muunganisho wa intaneti mara ya kwanza ili Gradle ipakue Android Gradle Plugin

## Jinsi ya kujenga APK
1. Fungua Android Studio.
2. Chagua **Open** kisha chagua folda `BUDUMAGI_ELECTRONICS_Android`.
3. Subiri Gradle Sync imalize. Ikiuliza kusakinisha SDK Platform 35, kubali.
4. Chagua **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK ya debug itapatikana kwa kawaida hapa:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Hamisha APK kwenye simu ya Android na usakinishe. Huenda simu ikaomba uruhusu *Install unknown apps* kwa app uliyotumia kufungua faili.

## Vipengele vilivyopo
- PIN ya mmiliki wakati wa kuanza na kuingia kwa mmiliki/mfanyakazi
- Hifadhidata ya ndani ya simu (SQLite)
- Bidhaa, barcode kama maandishi, stock na kiwango cha tahadhari
- Kurekodi mauzo na kukata stock
- Madeni ya wateja na malipo
- Matumizi ya biashara
- Muhtasari wa mauzo, faida ghafi, madeni na matumizi
- Ripoti CSV inayofunguka Excel, na kuchapisha/kusave PDF
- Backup JSON na kurejesha backup kupitia faili

## Muhimu kabla ya matumizi ya biashara
- Data inahifadhiwa ndani ya simu hii pekee. Hakuna cloud sync au backup ya moja kwa moja; tengeneza backup mara kwa mara.
- PIN inatumika kwa kufungua app. Toleo hili ni msingi wa ndani ya kifaa; usilisambaze kama mfumo wa usalama uliokaguliwa kitaalamu.
- Barcode kwa sasa huhifadhiwa/kuingizwa kama maandishi; kamera scanner haijaunganishwa katika toleo hili.
- Hakuna APK iliyojengwa ndani ya mazingira haya. Mradi huu unahitaji kujengwa kwa Android Studio kwa hatua zilizo hapo juu.
